import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Demostracion sencilla del comportamiento LIFO de una pila.
 * Guarda letras y muestra las operaciones principales.
 */
public class PilaLIFO {
    public static void main(String[] args) {
        // Creamos una pila vacia de cadenas de texto.
        Deque<String> pila = new ArrayDeque<>();

        System.out.println("¿La pila está vacía? " + pila.isEmpty());

        // PUSH: inserta elementos en la cima de la pila.
        pila.push("A");
        pila.push("B");
        pila.push("C");
        System.out.println("Pila después de agregar A, B y C: " + pila);

        // PEEK: consulta la cima sin retirar el elemento.
        System.out.println("Elemento en la cima: " + pila.peek());

        // POP: retira la cima. Verificamos que no esté vacía.
        if (!pila.isEmpty()) {
            System.out.println("Elemento retirado: " + pila.pop());
        }

        System.out.println("Pila después de retirar: " + pila);
        System.out.println("Cantidad de elementos: " + pila.size());
    }
}
